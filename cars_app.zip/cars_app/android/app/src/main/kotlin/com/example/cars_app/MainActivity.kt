package com.example.cars_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
